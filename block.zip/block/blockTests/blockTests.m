//
//  blockTests.m
//  blockTests
//
//  Created by hu on 14-9-12.
//  Copyright (c) 2014年 udows. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface blockTests : XCTestCase

@end

@implementation blockTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
