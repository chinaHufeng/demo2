//
//  BViewController.h
//  block
//
//  Created by hu on 14-9-12.
//  Copyright (c) 2014年 udows. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^myBlock)(void);
@interface BViewController : UIViewController
@property (nonatomic , copy) myBlock loginSuccessBlock;
@end
