//
//  ViewController.m
//  block
//
//  Created by hu on 14-9-12.
//  Copyright (c) 2014年 udows. All rights reserved.
//

#import "ViewController.h"
#import "AViewController.h"
#import "BViewController.h"
@interface ViewController ()
{
    int i;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
	// Do any additional setup after loading the view, typically from a nib.
}
-(IBAction)push:(id)sender
{
    if (i==1) {
        AViewController *a=[[AViewController alloc]initWithNibName:@"AViewController" bundle:nil];
        [self.navigationController pushViewController:a animated:YES];
    }
    else{
        [self showLoginWithBlock:^(void) {
            NSLog(@"已经跳转");
//            AViewController *a=[[AViewController alloc]initWithNibName:@"AViewController" bundle:nil];
//         [self presentViewController:a animated:YES completion:nil];
        }];
    }
}
- (void)showLoginWithBlock:(myBlock)block
{
      void (^kl)( void );
    BViewController *a=[[BViewController alloc]initWithNibName:@"BViewController" bundle:nil];
    a.loginSuccessBlock=block;
    [self presentViewController:a animated:YES completion:^(void){
        block();
    }];
}
- (void)showBlock
{
  

   
    
//    int (^kl)( int ) = ^( int num)
//    {
//            return num;
//    };
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
